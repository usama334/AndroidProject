package com.example.hp.blooddonation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class my_requests extends AppCompatActivity {

    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    my_requests_adapter adapter;
    ArrayList<my_requests_model_class> contacts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setContacts();
    }

    private void setContacts() {
        contacts.add(new my_requests_model_class("Usama","03319868354","CMH","Rawalpindi","O+ve","Male"));
        contacts.add(new my_requests_model_class("Ali","03329468354","CMH","Rawalpindi","O+ve","Male"));
        contacts.add(new my_requests_model_class("Haider","03451268354","CMH","Rawalpindi","O+ve","Male"));



    }

    private void initViews() {
        recyclerView=findViewById(R.id.recycle_view_my_requests);
        linearLayoutManager=new LinearLayoutManager(this);
        contacts=new ArrayList<>();
        adapter=new my_requests_adapter(contacts,this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);

    }
}
