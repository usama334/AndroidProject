package com.example.hp.blooddonation;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class sign_up extends AppCompatActivity {


    private EditText inputEmail, inputPassword,inputName,inputLoc,inputNum;     //hit option + enter if you on mac , for windows hit ctrl + enter
    private Button  btnSignUp;
    private TextView btnSignIn;
    private Spinner  inputGender,inputBG,inputDonation;
    private ProgressBar progressBar;

    DatabaseReference users;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        initVars();

//        btnResetPassword.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(sign_up.this, forgot_password.class));
//            }
//        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i=new Intent(sign_up.this,login.class);
               startActivity(i);
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();

                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Log.d("sign", "onclick function me agya step 3 ");
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {

                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                //create user
                addusers();



            }
        });
    }
    private  void initVars(){
        btnSignIn = (TextView) findViewById(R.id.sign_in_button);
        btnSignUp = (Button) findViewById(R.id.sign_up_button);
        inputEmail = (EditText) findViewById(R.id.email);
        inputPassword = (EditText) findViewById(R.id.password);
        inputBG=(Spinner) findViewById(R.id.spn_blood_group);
        inputGender=(Spinner) findViewById(R.id.spn_gender);
        inputLoc=(EditText)findViewById(R.id.edt_location);
        inputName=(EditText)findViewById(R.id.edt_name);
        inputNum=(EditText)findViewById(R.id.edt_number);
        inputDonation=(Spinner)findViewById(R.id.spn_donor);
        users=FirebaseDatabase.getInstance().getReference().child("Users");

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        //    btnResetPassword = (Button) findViewById(R.id.btn_reset_password);


    }

    private void addusers() {
        String user_name,user_gender,user_loc,user_bg,user_email,user_no,user_pass;
        String donation;

        String test="test";
        user_name=inputName.getText().toString();
        user_bg=inputBG.getSelectedItem().toString();
        user_email=inputEmail.getText().toString();
        user_loc=inputLoc.getText().toString();
        user_gender=inputGender.getSelectedItem().toString();
        user_no=inputNum.getText().toString();
        user_pass=inputPassword.getText().toString();
        donation=inputDonation.getSelectedItem().toString();
        Log.d(test, inputName.getText()+" "+inputGender.getSelectedItem().toString());
        Users myuser;

        if (donation.equals("Yes")){
            myuser=new Users(user_name,user_email,user_pass,user_gender,user_loc,user_bg,user_no,1);
        }
        else {
            myuser=new Users(user_name,user_email,user_pass,user_gender,user_loc,user_bg,user_no,0);
        }

        users.push().setValue(myuser);
        Toast.makeText(sign_up.this, donation, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }
}
