package com.example.hp.blooddonation;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class myProfile extends AppCompatActivity {
     TextView profile_name, profile_email,profile_city,profile_country,profile_bg,profile_number;
     FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        initVars();
        setDbValues();
    }

    private void setDbValues() {
        DatabaseReference path=FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

    }

    @SuppressLint("WrongViewCast")
    private void initVars() {
        profile_name=findViewById(R.id.txt_profile_name);
        profile_city=findViewById(R.id.txt_profile_city);
        profile_country=findViewById(R.id.txt_profile_country);
        profile_bg=findViewById(R.id.txt_profile_bgroup);
        profile_email=findViewById(R.id.txt_profile_email);
        profile_number=findViewById(R.id.txt_profile_number);

        auth= FirebaseAuth.getInstance();
    }
}
