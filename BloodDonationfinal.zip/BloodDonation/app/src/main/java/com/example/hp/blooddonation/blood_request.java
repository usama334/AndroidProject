package com.example.hp.blooddonation;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Calendar;

public class blood_request extends AppCompatActivity {
    EditText edt_req_name, edt_req_hospital, edt_req_no,edt_req_amount,edt_req_city,edt_req_date,edt_req_msg;
    Spinner  edt_req_bg;
    DatePickerDialog picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_request);
        initVars();
        edt_req_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(blood_request.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                edt_req_date.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });
    }

    private void initVars() {
        edt_req_name=(EditText)findViewById(R.id.req_name);
        edt_req_amount=(EditText)findViewById(R.id.req_quantity);
        edt_req_hospital=(EditText)findViewById(R.id.req_hospital);
        edt_req_city=(EditText)findViewById(R.id.req_city);
        edt_req_msg=(EditText)findViewById(R.id.req_msg);
        edt_req_no=(EditText)findViewById(R.id.req_contact);
        edt_req_bg=(Spinner) findViewById(R.id.req_bg);
        edt_req_date=findViewById(R.id.req_date);
        edt_req_date.setInputType(InputType.TYPE_NULL);

    }

}
